# SafeKid — déploiement sur Netlify

1. Mettez ce dossier dans un dépôt GitHub (Netlify > Add new site > Import from Git).
   Le glisser-déposer simple ne fonctionne PAS : les fonctions serveur et le stockage ont besoin d'un build.
   Alternative sans GitHub : `npm i -g netlify-cli`, puis `netlify deploy --prod` dans ce dossier.
2. Netlify > Site configuration > Environment variables : ajoutez `ADMIN_PASSWORD` (votre mot de passe admin).
   Optionnel : `SESSION_SECRET` (une longue chaîne aléatoire).
3. Redéployez (Deploys > Trigger deploy).
4. Ouvrez `https://VOTRE-SITE.netlify.app/admin`, connectez-vous, créez un bracelet, téléchargez le QR.

Les données sont stockées dans Netlify Blobs (inclus, rien à configurer).
Les QR codes pointent vers le domaine depuis lequel vous êtes connecté à /admin : si vous changez de domaine
(ex. safekid.sn), recréez/réimprimez les QR avant gravure. Choisissez donc votre domaine définitif avant d'imprimer.

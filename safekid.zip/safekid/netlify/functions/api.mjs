import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const config = { path: "/api/*" };

const J = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const secret = () => process.env.SESSION_SECRET || "sk:" + process.env.ADMIN_PASSWORD;
const sign = (p) => crypto.createHmac("sha256", secret()).update(p).digest("hex");
const mkToken = () => { const e = Date.now() + 12 * 3600e3; return e + "." + sign("" + e); };
const hash = (s) => crypto.createHash("sha256").update(String(s)).digest();
function authed(req) {
  const t = (req.headers.get("authorization") || "").replace("Bearer ", "");
  const [e, s] = t.split(".");
  if (!e || !s || +e < Date.now()) return false;
  const x = sign(e);
  return x.length === s.length && crypto.timingSafeEqual(Buffer.from(x), Buffer.from(s));
}
const slugify = (n) => n.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "enfant";
function cleanPhone(p) {
  let d = String(p || "").replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  if (d.length === 9) d = "221" + d; // numéro sénégalais sans indicatif
  return d.length >= 10 && d.length <= 15 ? d : null;
}

export default async (req) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const store = getStore("safekid");
  const get = async (code) => store.get("b:" + code, { type: "json" });
  const put = (b) => store.setJSON("b:" + b.code, b);

  try {
    // ---------- Connexion ----------
    if (parts[0] === "login" && req.method === "POST") {
      const { password } = await req.json();
      const admin = process.env.ADMIN_PASSWORD;
      if (!admin) return J({ error: "ADMIN_PASSWORD n'est pas défini dans Netlify." }, 500);
      if (!crypto.timingSafeEqual(hash(password), hash(admin))) return J({ error: "Mot de passe incorrect." }, 401);
      return J({ token: mkToken() });
    }

    // ---------- Public (jamais de numéro dans les réponses) ----------
    if (parts[0] === "public" && parts[1]) {
      const b = await get(parts[1]);
      if (!b) return J({ error: "not_found" }, 404);
      if (b.status !== "active") return J({ active: false });
      b.scans = (b.scans || 0) + 1; b.lastScan = new Date().toISOString();
      await put(b);
      return J({ active: true, name: b.name, age: b.age || null, number: b.serial.split("-").pop() });
    }
    if ((parts[0] === "call" || parts[0] === "wa") && parts[1]) {
      const b = await get(parts[1]);
      if (!b || b.status !== "active") return new Response("Bracelet indisponible", { status: 404 });
      if (parts[0] === "call") return Response.redirect("tel:+" + b.phone, 302);
      const lat = url.searchParams.get("lat"), lng = url.searchParams.get("lng");
      let msg = `Bonjour, j'ai trouvé ${b.name} avec son bracelet SafeKid.`;
      if (/^-?\d+(\.\d+)?$/.test(lat || "") && /^-?\d+(\.\d+)?$/.test(lng || "")) msg += ` Voici ma position : https://maps.google.com/?q=${lat},${lng}`;
      return Response.redirect(`https://wa.me/${b.phone}?text=${encodeURIComponent(msg)}`, 302);
    }

    // ---------- Admin ----------
    if (parts[0] === "admin") {
      if (!authed(req)) return J({ error: "Session expirée." }, 401);

      if (parts[1] === "bracelets" && !parts[2] && req.method === "GET") {
        const { blobs } = await store.list({ prefix: "b:" });
        const all = (await Promise.all(blobs.map((x) => store.get(x.key, { type: "json" })))).filter(Boolean);
        all.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        return J({ bracelets: all });
      }

      if (parts[1] === "bracelets" && !parts[2] && req.method === "POST") {
        const { name, phone, age } = await req.json();
        const ph = cleanPhone(phone);
        if (!name || name.trim().length < 2) return J({ error: "Le prénom et nom de l'enfant sont obligatoires." }, 400);
        if (!ph) return J({ error: "Numéro de téléphone invalide." }, 400);
        const base = slugify(name);
        let code = base, i = 1;
        while (await get(code)) code = base + "-" + ++i; // jamais de réattribution
        const year = new Date().getFullYear();
        const ck = "counter-" + year;
        const n = ((await store.get(ck, { type: "json" })) || 0) + 1;
        await store.setJSON(ck, n);
        const b = {
          code, name: name.trim(), phone: ph, age: age ? Number(age) : null,
          serial: `SK-${year}-${String(n).padStart(5, "0")}`, status: "active",
          createdAt: new Date().toISOString(), createdBy: "admin", scans: 0,
        };
        await put(b);
        return J({ bracelet: b }, 201);
      }

      if (parts[1] === "bracelets" && parts[2] && req.method === "PUT") {
        const b = await get(parts[2]);
        if (!b) return J({ error: "Bracelet introuvable." }, 404);
        const d = await req.json();
        if (d.name !== undefined) { if (d.name.trim().length < 2) return J({ error: "Nom invalide." }, 400); b.name = d.name.trim(); }
        if (d.phone !== undefined) { const ph = cleanPhone(d.phone); if (!ph) return J({ error: "Numéro de téléphone invalide." }, 400); b.phone = ph; }
        if (d.age !== undefined) b.age = d.age ? Number(d.age) : null;
        if (d.status === "active" || d.status === "inactive") b.status = d.status;
        await put(b);
        return J({ bracelet: b });
      }
    }
    return J({ error: "not_found" }, 404);
  } catch (e) {
    return J({ error: "Erreur serveur : " + e.message }, 500);
  }
};
